/**
 * datos.js — carga el archivo .dat correspondiente a la página
 * y rellena los elementos del DOM mediante data-txt="clave.anidada"
 *
 * Uso en cada index.html:
 *   <script src="/datos/datos.js" data-src="/datos/descarga.dat" defer></script>
 *
 * En el HTML, cualquier elemento con data-txt se rellena:
 *   <h1 data-txt="hero.titulo"></h1>
 *   <p  data-txt="hero.subtitulo"></p>
 *
 * Para listas, usar data-txt-list="clave" en el <ul>/<ol>:
 *   <ul data-txt-list="hero.pills"></ul>   → genera <li> por cada ítem
 *
 * Para atributos, usar data-txt-attr="atributo:clave":
 *   <a data-txt-attr="href:cta.enlace"></a>
 */

(function () {
  const script = document.currentScript ||
    document.querySelector('script[data-src]');
  if (!script) return;

  const src = script.getAttribute('data-src');
  if (!src) return;

  /** Obtiene un valor anidado por clave tipo "a.b.c" */
  function get(obj, path) {
    return path.split('.').reduce((o, k) => (o != null ? o[k] : undefined), obj);
  }

  fetch(src)
    .then(r => { if (!r.ok) throw new Error(r.status); return r.json(); })
    .then(data => {

      // ── Rellenar texto ──────────────────────────────────────────
      document.querySelectorAll('[data-txt]').forEach(el => {
        const val = get(data, el.dataset.txt);
        if (val != null) el.textContent = val;
      });

      // ── Rellenar HTML (permite <em>, <code>, etc.) ──────────────
      document.querySelectorAll('[data-html]').forEach(el => {
        const val = get(data, el.dataset.html);
        if (val != null) el.innerHTML = val;
      });

      // ── Rellenar atributos ──────────────────────────────────────
      document.querySelectorAll('[data-txt-attr]').forEach(el => {
        const [attr, key] = el.dataset.txtAttr.split(':');
        const val = get(data, key);
        if (val != null) el.setAttribute(attr, val);
      });

      // ── Generar listas ──────────────────────────────────────────
      document.querySelectorAll('[data-txt-list]').forEach(el => {
        const arr = get(data, el.dataset.txtList);
        if (!Array.isArray(arr)) return;
        el.innerHTML = arr.map(item =>
          `<li>${item}</li>`
        ).join('');
      });

      // ── Generar listas con clase personalizada ──────────────────
      document.querySelectorAll('[data-txt-pills]').forEach(el => {
        const arr = get(data, el.dataset.txtPills);
        if (!Array.isArray(arr)) return;
        const cls = el.dataset.pillClass || '';
        el.innerHTML = arr.map(item =>
          `<span class="${cls}">${item}</span>`
        ).join('');
      });

      // ── Generar tarjetas de descarga ────────────────────────────
      const grid = document.querySelector('[data-tarjetas]');
      if (grid) {
        const tarjetas = get(data, grid.dataset.tarjetas);
        if (Array.isArray(tarjetas)) {
          grid.innerHTML = tarjetas.map(t => `
            <article class="dl-card dl-card--${t.id}" role="listitem">
              <div class="dl-card-bar"></div>
              <div class="dl-card-icon" aria-hidden="true">${t.emoji || ''}</div>
              <div class="dl-card-body">
                <p class="dl-card-name">${t.nombre}</p>
                <span class="dl-card-type">${t.tipo}</span>
                <p class="dl-card-desc">${t.descripcion}</p>
                <div class="dl-chips">
                  ${t.chips.map(c => `<span class="dl-chip">${c}</span>`).join('')}
                </div>
                <ul class="dl-reqs" aria-label="Requisitos">
                  ${t.requisitos.map(r => `<li>${r}</li>`).join('')}
                </ul>
              </div>
              <div class="dl-card-footer">
                <a class="dl-btn ${t.disponible ? 'dl-btn--active' : 'dl-btn--soon'}"
                   ${t.disponible ? `href="${t.url}"` : 'aria-disabled="true" tabindex="0" role="button"'}>
                  ${t.boton}
                </a>
              </div>
            </article>
          `).join('');
        }
      }

      // ── Generar acordeón de descargas (inicio) ──────────────────
      const dlList = document.querySelector('[data-dl-list]');
      if (dlList) {
        const sistemas = get(data, dlList.dataset.dlList);
        if (Array.isArray(sistemas)) {
          dlList.innerHTML = sistemas.map(s => `
            <div class="dl-item">
              <button class="dl-toggle" aria-expanded="false" aria-controls="dl-${s.id}">
                <span class="dl-os">${s.nombre}</span>
                <span class="dl-badge">${s.badge}</span>
                <span class="dl-arrow" aria-hidden="true">▼</span>
              </button>
              <div class="dl-panel" id="dl-${s.id}" hidden>
                <p>${s.panel}</p>
              </div>
            </div>
          `).join('');

          // Re-adjuntar eventos del acordeón
          dlList.querySelectorAll('.dl-toggle').forEach(btn => {
            btn.addEventListener('click', () => {
              const expanded = btn.getAttribute('aria-expanded') === 'true';
              const panel = document.getElementById(btn.getAttribute('aria-controls'));
              btn.setAttribute('aria-expanded', String(!expanded));
              panel.hidden = expanded;
            });
          });
        }
      }

      // ── Pasos de "Cómo funciona" ────────────────────────────────
      document.querySelectorAll('[data-txt-steps]').forEach(el => {
        const arr = get(data, el.dataset.txtSteps);
        if (!Array.isArray(arr)) return;
        el.innerHTML = arr.map(s => `<li>${s}</li>`).join('');
      });

      // ── Meta título y descripción ───────────────────────────────
      const metaTitulo = get(data, 'meta.titulo');
      const metaDesc   = get(data, 'meta.descripcion');
      if (metaTitulo) document.title = metaTitulo;
      if (metaDesc) {
        const m = document.querySelector('meta[name="description"]');
        if (m) m.setAttribute('content', metaDesc);
      }

    })
    .catch(err => console.warn('[datos.js] No se pudo cargar', src, err));
})();
