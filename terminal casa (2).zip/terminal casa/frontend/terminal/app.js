/* ════════════════════════════════════════════════════════
   ICONOS SVG reutilizables
════════════════════════════════════════════════════════ */
const ICON_TERMINAL = `<svg class="tab-icon" viewBox="0 0 16 16" width="13" height="13"><polyline points="1,4 6,8 1,12" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><line x1="8" y1="12" x2="15" y2="12" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>`;

const ICON_WINDOWS = `<svg class="tab-icon" viewBox="0 0 16 16" width="13" height="13"><rect x="1" y="1" width="6.5" height="6.5" rx="0.5" fill="currentColor"/><rect x="8.5" y="1" width="6.5" height="6.5" rx="0.5" fill="currentColor"/><rect x="1" y="8.5" width="6.5" height="6.5" rx="0.5" fill="currentColor"/><rect x="8.5" y="8.5" width="6.5" height="6.5" rx="0.5" fill="currentColor"/></svg>`;

/* ════════════════════════════════════════════════════════
   ESTADO GLOBAL
════════════════════════════════════════════════════════ */
let tabCounter   = 0;   // ID único por pestaña
let activeTabId  = null;

const tabsContainer  = document.getElementById('tabs');
const panelsContainer = document.getElementById('panels-container');
const btnAdd         = document.getElementById('btn-add');
const dropdown       = document.getElementById('dropdown');

/* ════════════════════════════════════════════════════════
   DROPDOWN +
════════════════════════════════════════════════════════ */
btnAdd.addEventListener('click', (e) => {
  e.stopPropagation();
  dropdown.hidden = !dropdown.hidden;
  // Posicionar dropdown justo bajo el botón +
  const rect = btnAdd.getBoundingClientRect();
  dropdown.style.top  = (rect.bottom + 6) + 'px';
  dropdown.style.left = rect.left + 'px';
});

document.addEventListener('click', () => { dropdown.hidden = true; });

document.getElementById('add-terminal').addEventListener('click', () => {
  dropdown.hidden = true;
  createTab('terminal');
});

document.getElementById('add-windows').addEventListener('click', () => {
  dropdown.hidden = true;
  createTab('windows');
});

/* ════════════════════════════════════════════════════════
   ACTUALIZAR VISIBILIDAD DEL BOTÓN × 
   — solo aparece cuando hay más de 1 pestaña
════════════════════════════════════════════════════════ */
function updateCloseButtons() {
  const allTabs = tabsContainer.querySelectorAll('.tab');
  const showClose = allTabs.length > 1;
  allTabs.forEach(tab => {
    const closeBtn = tab.querySelector('.tab-close');
    if (closeBtn) closeBtn.style.display = showClose ? 'flex' : 'none';
  });
}
function createTab(type) {
  tabCounter++;
  const id    = `tab-${tabCounter}`;
  const panelId = `panel-${tabCounter}`;
  const label = type === 'terminal' ? 'Terminal' : 'Windows';
  const icon  = type === 'terminal' ? ICON_TERMINAL : ICON_WINDOWS;

  /* ── Botón de pestaña ── */
  const btn = document.createElement('button');
  btn.className   = 'tab';
  btn.id          = id;
  btn.dataset.panel = panelId;
  btn.dataset.type  = type;
  btn.innerHTML   = `
    ${icon}
    <span class="tab-label">${label}</span>
    <span class="tab-close" title="Cerrar">×</span>
  `;

  // Insertar ANTES del add-tab-wrapper
  const wrapper = document.querySelector('.add-tab-wrapper');
  tabsContainer.insertBefore(btn, wrapper);

  /* ── Panel ── */
  const panel = document.createElement('div');
  panel.className = 'panel hidden';
  panel.id        = panelId;
  panel.innerHTML = type === 'terminal'
    ? buildTerminalPanel(tabCounter)
    : buildWindowsPanel();
  panelsContainer.appendChild(panel);

  /* ── Eventos de la pestaña ── */
  btn.addEventListener('click', (e) => {
    // Si click en × → cerrar
    if (e.target.classList.contains('tab-close')) {
      closeTab(id, panelId);
      return;
    }
    switchTab(id, panelId);
    if (type === 'terminal') focusTerminal(panelId);
  });

  // Activar la nueva pestaña
  switchTab(id, panelId);
  if (type === 'terminal') {
    focusTerminal(panelId);
    // Cargar contenido inicial desde terminal_start.dat
    const termDiv = panel.querySelector('.terminal');
    const inp     = panel.querySelector('.cmd-input');
    if (termDiv && inp) loadStartContent(termDiv, inp);
  }

  // Actualizar visibilidad del ×
  updateCloseButtons();
}

/* ════════════════════════════════════════════════════════
   CERRAR PESTAÑA
════════════════════════════════════════════════════════ */
function closeTab(tabId, panelId) {
  const btn   = document.getElementById(tabId);
  const panel = document.getElementById(panelId);

  const wasActive = btn.classList.contains('active');
  btn.remove();
  if (panel) panel.remove();

  // Si era la activa, activar la anterior o la primera disponible
  if (wasActive) {
    const remaining = tabsContainer.querySelectorAll('.tab');
    if (remaining.length > 0) {
      const last = remaining[remaining.length - 1];
      switchTab(last.id, last.dataset.panel);
      if (last.dataset.type === 'terminal') focusTerminal(last.dataset.panel);
    }
  }

  // Actualizar visibilidad del ×
  updateCloseButtons();
}

/* ════════════════════════════════════════════════════════
   CAMBIAR PESTAÑA ACTIVA
════════════════════════════════════════════════════════ */
function switchTab(tabId, panelId) {
  // Desactivar todas
  tabsContainer.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  panelsContainer.querySelectorAll('.panel').forEach(p => p.classList.add('hidden'));

  // Activar la seleccionada
  const tab   = document.getElementById(tabId);
  const panel = document.getElementById(panelId);
  if (tab)   tab.classList.add('active');
  if (panel) panel.classList.remove('hidden');

  activeTabId = tabId;
}

/* ════════════════════════════════════════════════════════
   CARGAR terminal_start.dat e inyectarlo en un termDiv
════════════════════════════════════════════════════════ */
async function loadStartContent(termDiv, input) {
  try {
    const res  = await fetch('/terminal/start');
    const data = await res.json();
    if (!data.ok) return;

    const inputLine = input.closest('.input-line');
    data.lines.forEach(text => {
      const span = document.createElement('span');
      // Primera línea → negrita (título)
      span.className = 'line' + (text === data.lines[0] ? ' bold' : '');
      span.textContent = text.trim() === '' ? '\u00A0' : text;
      termDiv.insertBefore(span, inputLine);
    });
  } catch {
    // Si falla (ej: abriendo HTML directo sin server) muestra silenciosamente nada
  }
}
/* ════════════════════════════════════════════════════════
   CONSTRUIR PANEL TERMINAL — contenido desde .dat vía loadStartContent()
════════════════════════════════════════════════════════ */
function buildTerminalPanel(n) {
  return `
    <div class="terminal" id="terminal-${n}">
      <div class="input-line">
        <span class="prompt">terminal@terminal-temple ~ $</span>
        <input type="text" class="cmd-input" spellcheck="false" autocomplete="off" />
      </div>
    </div>
  `;
}

/* ════════════════════════════════════════════════════════
   CONSTRUIR PANEL WINDOWS
════════════════════════════════════════════════════════ */
function buildWindowsPanel() {
  return `
    <div class="windows-placeholder">
      <p>Remote Desktop — próximamente</p>
    </div>
  `;
}

/* ════════════════════════════════════════════════════════
   ENFOCAR INPUT DEL PANEL TERMINAL ACTIVO
════════════════════════════════════════════════════════ */
function focusTerminal(panelId) {
  const panel = document.getElementById(panelId);
  if (!panel) return;
  const input = panel.querySelector('.cmd-input');
  if (input) input.focus();
}

/* ════════════════════════════════════════════════════════
   LÓGICA DE TERMINAL (delegada — funciona en cualquier panel)
════════════════════════════════════════════════════════ */

// Clicks dentro de cualquier panel terminal → enfocar su input
let mouseDownX = 0, mouseDownY = 0;
document.addEventListener('mousedown', (e) => {
  mouseDownX = e.clientX;
  mouseDownY = e.clientY;
});
document.addEventListener('click', (e) => {
  const termDiv = e.target.closest('.terminal');
  if (!termDiv) return;
  const dx = Math.abs(e.clientX - mouseDownX);
  const dy = Math.abs(e.clientY - mouseDownY);
  if (dx > 4 || dy > 4) return;
  if (window.getSelection().toString().length > 0) return;
  const input = termDiv.querySelector('.cmd-input');
  if (input) input.focus();
});

// Enter en cualquier input de terminal
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  const input = e.target;
  if (!input.classList.contains('cmd-input')) return;

  const termDiv = input.closest('.terminal');
  const panel   = input.closest('.panel');
  if (!termDiv || !panel) return;

  const raw = input.value.trim();
  input.value = '';

  if (!raw) { printCommand(termDiv, input, ''); return; }

  printCommand(termDiv, input, raw);

  const [cmd, ...args] = raw.split(' ');
  runCommand(cmd, args, termDiv, input, panel);

  panel.scrollTop = panel.scrollHeight;
});

function runCommand(cmd, args, termDiv, input, panel) {
  const handlers = {
    help: () => [
      '',
      'Available commands:',
      '  help       — show this list',
      '  clear      — clear the terminal',
      '  date       — show current date & time',
      '  whoami     — show current user',
      '  echo <msg> — print a message',
      '  logout     — return to login screen',
      '',
    ],
    clear: () => {
      const inputLine = input.closest('.input-line');
      termDiv.innerHTML = '';
      termDiv.appendChild(inputLine);
      return null;
    },
    date:   () => ['', new Date().toString(), ''],
    whoami: () => ['', 'terminal@terminal-temple', ''],
    logout: () => {
      printLines(termDiv, input, ['', 'Logging out…', '']);
      setTimeout(async () => {
        try {
          const res  = await fetch('/logout', { method: 'POST' });
          const data = await res.json();
          window.location.href = data.redirect || '/login';
        } catch {
          window.location.href = '/login';
        }
      }, 500);
      return null;
    },
  };

  if (cmd === 'echo') {
    printLines(termDiv, input, [args.join(' ') || '']);
  } else if (handlers[cmd]) {
    const result = handlers[cmd]();
    if (result) printLines(termDiv, input, result);
  } else {
    printLines(termDiv, input, [`bash: ${cmd}: command not found`], 'error');
  }
}

function printLines(termDiv, input, lines, cssClass = '') {
  const inputLine = input.closest('.input-line');
  lines.forEach(text => {
    const span = document.createElement('span');
    span.className = 'line' + (cssClass ? ' ' + cssClass : '');
    span.textContent = text === '' ? '\u00A0' : text;
    termDiv.insertBefore(span, inputLine);
  });
  const panel = termDiv.closest('.panel');
  if (panel) panel.scrollTop = panel.scrollHeight;
}

function printCommand(termDiv, input, cmd) {
  const inputLine = input.closest('.input-line');
  const span = document.createElement('span');
  span.className = 'line command';
  span.textContent = `terminal@terminal-temple ~ $ ${cmd}`;
  termDiv.insertBefore(span, inputLine);
}

/* ════════════════════════════════════════════════════════
   INICIALIZAR — conectar las pestañas estáticas del HTML
════════════════════════════════════════════════════════ */
(function initStaticTabs() {
  // Agregar el × a la pestaña estática (oculto por defecto si es la única)
  const staticTab = document.querySelector('.tab[data-static]');
  if (staticTab) {
    const closeSpan = document.createElement('span');
    closeSpan.className = 'tab-close';
    closeSpan.title = 'Cerrar';
    closeSpan.textContent = '×';
    closeSpan.style.display = 'none'; // oculto hasta que haya más de 1
    staticTab.appendChild(closeSpan);

    staticTab.addEventListener('click', (e) => {
      if (e.target.classList.contains('tab-close')) {
        closeTab(staticTab.id, staticTab.dataset.panel);
        return;
      }
      switchTab(staticTab.id, staticTab.dataset.panel);
      if (staticTab.dataset.type === 'terminal') focusTerminal(staticTab.dataset.panel);
    });
  }

  // Activar la pestaña inicial y cargar el .dat
  if (staticTab) {
    switchTab(staticTab.id, staticTab.dataset.panel);
    const termDiv = document.querySelector('#panel-terminal .terminal');
    const inp     = document.querySelector('#panel-terminal .cmd-input');
    if (termDiv && inp) loadStartContent(termDiv, inp);
  }
  updateCloseButtons();
})();
