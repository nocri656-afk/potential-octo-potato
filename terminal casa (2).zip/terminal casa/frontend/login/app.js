const input       = document.querySelector('.access-input');
const errorMsg    = document.getElementById('error-msg');
const defaultValue = 'login@terminal-temple (login)';

// Limpiar placeholder al enfocar
input.addEventListener('focus', () => {
  if (input.value === defaultValue) input.value = '';
});

// Restaurar placeholder si queda vacío
input.addEventListener('blur', () => {
  if (input.value.trim() === '') input.value = defaultValue;
});

// Enviar código al servidor con Enter
input.addEventListener('keydown', async (e) => {
  if (e.key !== 'Enter') return;

  const code = input.value.trim();
  if (!code || code === defaultValue) return;

  try {
    const res  = await fetch('/login', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ code }),
    });

    const data = await res.json();

    if (data.ok) {
      // Sesión iniciada → ir a /terminal
      window.location.href = data.redirect;
    } else {
      // Código incorrecto
      showError(data.message || 'Código incorrecto');
      input.value = '';
      input.focus();
    }
  } catch {
    showError('Error de conexión con el servidor');
  }
});

function showError(msg) {
  if (!errorMsg) return;
  errorMsg.textContent = msg;
  errorMsg.style.display = 'block';
  setTimeout(() => { errorMsg.style.display = 'none'; }, 3000);
}
