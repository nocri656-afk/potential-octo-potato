require('dotenv').config();

const express      = require('express');
const session      = require('express-session');
const path         = require('path');
const fs           = require('fs');

const app    = express();
const PORT   = process.env.PORT   || 3000;
const SECRET = process.env.SESSION_SECRET || 'dev_secret';
const ACCESS = process.env.ACCESS_CODE;

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use(session({
  secret:            SECRET,
  resave:            false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'strict',
    // secure: true  ← activar cuando uses HTTPS
  },
}));

// ── Guard: solo usuarios autenticados pueden acceder a /terminal ──────────────
function requireAuth(req, res, next) {
  if (req.session && req.session.authenticated) return next();
  // Acceso directo a /terminal sin sesión → vuelve al login
  return res.redirect('/login');
}

// ── Archivos estáticos de login (css, js) ─────────────────────────────────────
app.use('/login',    express.static(path.join(__dirname, 'frontend', 'login')));

// ── Logo público (accesible sin autenticación) ────────────────────────────────
app.use('/logo',     express.static(path.join(__dirname, 'logo')));

// ── Archivos estáticos de terminal (css, js) — protegidos ────────────────────
app.use('/terminal', requireAuth, express.static(path.join(__dirname, 'frontend', 'terminal')));

// ── GET /  →  redirige a /login ───────────────────────────────────────────────
app.get('/', (req, res) => {
  if (req.session.authenticated) return res.redirect('/terminal');
  res.redirect('/login');
});

// ── GET /login  →  sirve index.html del login ─────────────────────────────────
app.get('/login', (req, res) => {
  if (req.session.authenticated) return res.redirect('/terminal');
  res.sendFile(path.join(__dirname, 'frontend', 'login', 'index.html'));
});

// ── POST /login  →  valida el código ─────────────────────────────────────────
app.post('/login', (req, res) => {
  const { code } = req.body;

  if (!code || code.trim() !== ACCESS) {
    return res.status(401).json({ ok: false, message: 'Código incorrecto' });
  }

  // Regenerar sesión para evitar session fixation y limpiar estado anterior
  req.session.regenerate((err) => {
    if (err) {
      return res.status(500).json({ ok: false, message: 'Error al iniciar sesión' });
    }
    req.session.authenticated = true;
    return res.json({ ok: true, redirect: '/terminal' });
  });
});

// ── GET /terminal  →  protegido, sirve index.html de terminal ─────────────────
app.get('/terminal', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'terminal', 'index.html'));
});

// ── GET /terminal/start  →  sirve el contenido del .dat como JSON ─────────────
app.get('/terminal/start', requireAuth, (req, res) => {
  const datPath = path.join(__dirname, 'terminal_start.dat');
  fs.readFile(datPath, 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ ok: false, message: 'No se pudo leer terminal_start.dat' });
    }
    // Cada línea del .dat es un elemento del array
    const lines = data.split('\n').map(l => l.replace(/\r$/, ''));
    res.json({ ok: true, lines });
  });
});

// ── POST /logout  →  destruye la sesión y vuelve a login ─────────────────────
app.post('/logout', (req, res) => {
  req.session.destroy((err) => {
    res.clearCookie('connect.sid');
    res.json({ ok: true, redirect: '/login' });
  });
});

// ── 404 ───────────────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.redirect('/login');
});

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`Nik http://localhost:${PORT}`);
});
